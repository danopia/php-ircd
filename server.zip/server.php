<?php
// MonoNet protocol version 0.1 server
// written and copyright 2008 Nick Markwell (RcokerMONO/duck)
// feel free to edit and distribute as long as you leave my original credit for this

$config=Array();
$config['name'] = 'homebrew.danopia.no-ip.org';
$config['max_len'] = 512;
$config['max_users'] = 25;
$config['port'] = 7000;
$config['line_ending'] = "\n";

$sockets = array();
$channels = array();
$queues = array();
$sock_num = 0;

function socket_normal_read($socket)
{
	global $config, $sockets, $queues, $sock_num;
	for ($i = 0; isset ($sockets[$i]) && $socket != $sockets[$i]; $i++);

	if (!isset ($sockets[$i])) {
		$sockets [$sock_num] = $socket;
		$queues [$sock_num++] = "";
	}

	$recv = socket_read ($socket, $config['max_len']);
//$recv = str_replace($recv, "\r", "");
	if ($recv === "") {
		if (strpos ($queues[$i], $config['line_ending']) === false)
			return false;
	}
	else if ($recv !== false) {
		$queues[$i] .= $recv;
	}

	$pos = strpos ($queues[$i], $config['line_ending']);
	if ($pos === false)
		return "";
	$ret = substr ($queues[$i], 0, $pos);
	$queues[$i] = substr ($queues[$i], $pos+1);

	return $ret;
}

function validate_nick($nick)
{
	return preg_match('/^[a-zA-Z\[\]_|`^][a-zA-Z0-9\[\]_|`^]{0,29}$/', $nick);
}
function validate_chan($chan)
{
	return preg_match('/^#[a-zA-Z0-9`~!@#$%^&*\(\)\'";|}{\]\[.<>?]{0,29}$/', $chan);
}

function array_removal($val, &$arr)
{
	$i = array_search($val, $arr);
	if($i === false) return false;
	$arr = array_merge(array_slice($arr, 0, $i), array_slice($arr, $i + 1));
	return true;
}

function nick_removal($nick, &$arr)
{
	foreach($arr as $id => $him)
	{
		if(strtolower($him['nick']) == strtolower($nick))
			return array_removal($him, $arr);
	}
}

//error_reporting(E_ERROR | E_PARSE);
error_reporting(E_ALL);

set_time_limit(0);

$version = 0.0;
$ver_str = (string)$version;
if(!stristr($ver_str, '.'))
{
	$version = number_format($version, 1);
	$ver_str = (string)$version;
}

$sock = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
socket_bind($sock, '0.0.0.0', $config['port']);
if (socket_last_error() != 0)
	echo socket_last_error() . ': ' . socket_strerror(socket_last_error());
socket_listen($sock, $config['max_users']);
$conn = array();

socket_set_nonblock($sock);

//file_put_contents("status.txt", "up");

while (true)
	include('connection_handler.php');

function dns_timeout($ip) {
	$res = `nslookup -timeout=3 -retry=1 $ip`;
	if (preg_match('/\nName:(.*)\n/', $res, $out)) {
		return trim($out[1]);
	} else {
		return $ip;
	}
}

function kill($who, $reason)
{
	global $channels;
	$sentto = array($who);
	foreach($channels as &$channel)
	{
		if(in_array($who, $channel['nicks']))
		{
			foreach($channel['nicks'] as $user)
			{
				if(!in_array($user, $sentto))
				{
					send($user, ':' . $who['nick'] . '!' . $who['ident'] . '@' . $who['cloak'] . ' QUIT :' . $reason);
					$sentto[] = $user;
				}
			}
			nick_removal($who['nick'], $channel['nicks']);
		}
	}
	send($who, 'ERROR :Closing Link: ' . $who['nick'] . '[' . $who['cloak'] . '] (' . $reason . ')');
	socket_close($who['sock']);
	array_removal($who, $conn);
}

function send($who, $text)
{
	socket_write($who['sock'], $text . "\r\n");
	echo $who['nick'] . ' >>> ' . $text . "\r\n";
	// if (socket_last_error($who['sock']) != 0)
		// echo socket_last_error($who['sock']) . ': ' . socket_strerror(socket_last_error($who['sock'])) . "\r\n";
}

?>
